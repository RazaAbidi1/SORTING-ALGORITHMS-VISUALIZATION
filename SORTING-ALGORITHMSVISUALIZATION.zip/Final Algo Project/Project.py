from graphlib import TopologicalSorter
from tkinter import *
from tkinter import ttk, messagebox
from tkinter import filedialog
import tkinter
import tkinter as tk
from tkinter.tix import IMAGETEXT
from PIL import Image, ImageTk
from matplotlib import pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib as mp
import time

speed = 100

root=Tk()
root.config(bg='maroon')

s = ttk.Style()
s.configure('Wild.TRadiobutton', background='maroon', foreground='white')
s.configure('Frame.TFrame', background='maroon')
s.configure('Combobox.TCombobox', background='maroon')
root.title("Sorting Algorithms Visualization")
root.geometry("1200x800")
v=IntVar() 
image = Image.open('main.jpeg')
tk_image = ImageTk.PhotoImage(image)

label = tk.Label(root, font=("Times", "19", "bold "),fg='whitesmoke',  text=' \t\t\t Design and Analysis of Algorithm Project\n\n\t\t\t\t\t    Presented By:\n\t\t\t\t\tAmna Mubarak (20k-1695)  \n\t\t\t\t\tRaza Abidi (20k-1061) \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n', image=tk_image, compound='center')

label.pack()
labelText=StringVar()
label=ttk.Label(root,style='Label.TLabel',background='grey',textvariable=labelText)
labelText.set( "Select Input File")
label.pack()
for i in range(1,6):
    ttk.Radiobutton(root,style='Wild.TRadiobutton',variable=v,value=i,text="FILE No."+str(i)).pack()
 
def file_reading(): 
    Array = []
    file = v.get()
    with open("f"+str(file)+".txt") as f:
        for i, line in enumerate(f):
            Array.append(int(line.strip()))

        
    new_window(Array)

def Insertion_Sort(arr):
    print(arr)
    for i in range(1, len(arr)):
       key = arr[i]
       j = i - 1

       while j >= 0 and key < arr[j]:
           arr[j + 1] = arr[j]
           j = j - 1
           yield arr
       arr[j + 1] = key   
    print(arr,'insertion')

def Bubble_Sort(arr):
    val = True
    for i in range(len(arr) - 1):
        if not val:
            return
        val = False

        for j in range(len(arr) - 1 - i):
            if arr[j] > arr[j + 1]:
                perform_swap(arr, j, j + 1)
                val = True
            yield arr


def Merge_Sort(arr):
   i = j = k = 0
   if len(arr) > 1:
       mid = len(arr) // 2
       left = arr[:mid]
       right = arr[mid:]
 
       yield from Merge_Sort(left)
       yield from Merge_Sort(right)
       
       while i < len(left) and j < len(right):
           if left[i] <= right[j]:
               arr[k] = left[i]
               yield arr
               i += 1
           else:
               arr[k] = right[j]
               yield arr
               j += 1
           k += 1
           yield arr

       while i < len(left):
           arr[k] = left[i]
           i += 1
           k += 1

       while j < len(right):
           arr[k] = right[j]
           j += 1
           k += 1

def Heap_Sort(arr):
   arr_len = len(arr)

   for i in range(arr_len // 2, -1, -1):
       yield from Heapify(arr, arr_len, i)

   for i in range(arr_len - 1, 0, -1):
       arr[i], arr[0] = arr[0], arr[i]
       
       yield from Heapify(arr, i, 0)

def Heapify(arr, arr_len, i):
   
   large = i
   left = 2 * i + 1
   right = 2 * i + 2
   
   if left < arr_len and arr[i] < arr[left]:
       large = left
       yield arr

   if right < arr_len and arr[large] < arr[right]:
       large = right
       yield arr

   if large != i:
       arr[i], arr[large] = arr[large], arr[i]
       yield arr
       yield from Heapify(arr, arr_len, large)

def Quick_Sort(arr,left,right):
    if left >= right:
        return
    x = arr[left]
    j = left
    for i in range(left + 1, right + 1):
        if arr[i] <= x: 
            j += 1
            arr[j], arr[i] = arr[i], arr[j]
        yield arr
    arr[left], arr[j]= arr[j], arr[left]
    yield arr
    yield from  Quick_Sort(arr, left, j-1)
    yield from Quick_Sort(arr, j + 1, right)

def Counting_Sort_Helper(arr, pos):
   size = len(arr)
   output = [0] * size
   count = [0] * 10

  
   for i in range(0, size):
       index = arr[i] // pos
       count[index % 10] += 1

  
   for i in range(1, 10):
       count[i] += count[i - 1]
    
   i = size - 1
   while i >= 0:
       index = arr[i] // pos
       output[count[index % 10] - 1] = arr[i]
       count[index % 10] -= 1
       i -= 1

   for i in range(0, size):
       arr[i] = output[i]
       yield arr


def Radix_Sort(arr):
   max1 = max(arr)

   pos = 1
   while max1 // pos > 0:
       yield from Counting_Sort_Helper(arr, pos)
       pos *= 10
    
def Bucket_Sort(arr):
    
    b = [] 
    for i in range(len(arr)):
        b.append([])

    for i in arr:
        index_b = int(10 * i / 100)
        b[index_b].append(i)
        yield arr
  
    for i in range(len(arr)):
        b[i] = sorted(b[i])
        yield arr

    k = 0
    for i in range(len(arr)):
        for j in range(len(b[i])):
            arr[k] = b[i][j]
            k += 1
            yield arr
    return arr

def Counting_Sort(arr):
    Array_len = len(arr)
    result = [0] * Array_len
    
    countArray = [0] * 100
    for i in range(0, Array_len):
        countArray[arr[i]] += 1
        
    for i in range(1, 100):
        countArray[i] += countArray[i - 1]
    i = Array_len - 1
    while i >= 0:
        result[countArray[arr[i]] - 1] = arr[i]
        countArray[arr[i]] -= 1
        i -= 1
    for i in range(0,Array_len):
        arr[i] = result[i]
        yield arr
def Count_Range_Sort_824(arr, n,m):

    Array_len = len(arr)
    result = [0] * Array_len
    
    countArray = [0] * 100
    C = [0] * 100
    for i in range(0, Array_len):
        countArray[arr[i]] += 1

    C[0] = countArray[0]
    print("C[0] = ", countArray[32])
    for i in range(1, 100):
        C[i] = countArray[i] + C[i - 1]    
        
    for i in range(1, 100):
        countArray[i] += countArray[i - 1]
    i = Array_len - 1
    while i >= 0:
        result[countArray[arr[i]] - 1] = arr[i]
        countArray[arr[i]] -= 1
        i -= 1
    for i in range(0,Array_len):
        arr[i] = result[i]
        yield arr

    print("Number of elements in the range [", n, ",", m, "] is: ", C[m] - C[n] + countArray[n])
    
def Partition(arr, low, high):
    pivot = arr[high]
    border=high
    i = j = low
    for i in range(low, high):
        if arr[i]<pivot:
            arr[i], arr[j]= arr[j], arr[i]
               
            j+= 1                     
    arr[j], arr[high]= arr[high],arr[j]
    return j

def Insertion_Sort_Helper(arr, low, n):
    for i in range(low + 1, n + 1):
        val = arr[i]
        j = i
        while j>low and arr[j-1]>val:
            arr[j]= arr[j-1]   
            j-= 1
        arr[j]= val   

def hybrid_quick_sort_725(arr, low, high):
    while low<high:
        if high-low + 1<10:
            Insertion_Sort_Helper(arr, low, high)
            break
        else:
            pivot = Partition(arr, low, high)
            if pivot-low<high-pivot:
                yield from hybrid_quick_sort_725(arr, low, pivot-1)
                low = pivot + 1
            else:
                yield from hybrid_quick_sort_725(arr, pivot + 1, high)
                high = pivot-1
        yield arr
    yield arr
    
def perform_swap(A, i, j):
    A[i], A[j] = A[j], A[i]


def Display_Visualization(iterator,arr):
    generator = None
    print(iterator, 'iterator')
    if iterator == 1:
        generator = Insertion_Sort(arr)
    elif iterator == 2:
        generator = Bubble_Sort(arr)  
          
    elif iterator == 3:
        generator = Merge_Sort(arr)
        
    elif iterator == 4:
        generator = Heap_Sort(arr)
        
    if iterator == 5:
        generator = Quick_Sort(arr, 0, len(arr) - 1)    
        
    elif iterator == 6:
        generator = Radix_Sort(arr)
        
    elif iterator == 7:
        generator = Bucket_Sort(arr)
    
    elif iterator == 8:
        generator = Counting_Sort(arr)  
           
    elif iterator == 9:
        generator = hybrid_quick_sort_725(arr, 0 , len(arr) - 1) 
        
    elif iterator == 10:
        generator = Count_Range_Sort_824(arr,10,20)    
        
              
    plt.style.use('fivethirtyeight')     
    data_normalizer = mp.colors.Normalize()
    color_map = mp.colors.LinearSegmentedColormap(
        "my_map",
        {
            "red": [(0, 1.0, 1.0),
                    (1.0, .5, .5)],
            "green": [(0, 0.5, 0.5),
                    (1.0, 0, 0)],
            "blue": [(0, 0.50, 0.5),
                    (1.0, 0, 0)]
        }
    )

    fig, ax = plt.subplots()

    if iterator == 1:
        plt.title(
        "Insertion Sort Visualization   O(n)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')
    
    elif iterator == 2:
        plt.title(
        "Bubble Sort Visualization   O(n)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')
            
    elif iterator == 3:
        plt.title(
        "Merge Sort Visualization   O(nlogn)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')

    elif iterator == 4:
        plt.title(
        "Heap Sort Visualization   O(nlogn)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')
        
    elif iterator == 5:
        plt.title("Quick Sort Visualization   O(nlogn) ",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')
            
    
    elif iterator == 6:
        plt.title(
        "Radix Sort Visualization   O(n.k)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')

    elif iterator == 7:
        plt.title(
        "Bucket Sort Visualization   O(n+k)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')
    
        
    elif iterator == 8:
        plt.title(
        "Counting Sort Visualization   O(n+k)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')
        
    elif iterator == 9:
         plt.title(
        "hybrid_quick_725 Sorting Visualization   O(nlogn/k)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')   
    
    elif iterator == 10:
         plt.title(
        "Count_Range_824 Sorting Visualization   O(n+k)",
        fontsize='large',
        loc='left',
        fontweight='bold',
        style='italic',
        family='monospace')        

    sub_plot = ax.bar(range(len(arr)), arr, align="edge",  color=color_map(data_normalizer(range(len(arr)))))
    ax.set_xlim(0, len(arr))
    
    text = ax.text(0.01, 0.95, "", transform=ax.transAxes)
    iteration = [0]

    def Animate(arr, rects, iteration):
        for rect, itr in zip(rects, arr):
            rect.set_height(itr)
        iteration[0] += 1
        text.set_text(f"# of operations: {iteration[0]}")


    anim = FuncAnimation(    
        fig,
        func=Animate,
        fargs=(sub_plot, iteration),
        frames=generator,
        repeat=False,
        interval=15,
    )
    plt.show()


def Sorting_Algorithms(Array,val):
    iterator = 0
    print(val, 'this is val')
    if val == 'Insertion Sort': 
        iterator = 1
    elif val == 'Bubble Sort':
        iterator = 2
    elif val == 'Merge Sort':
        iterator = 3
    elif val == 'Heap Sort':
        iterator = 4
    elif val == 'Quick Sort':
        iterator = 5   
    elif val == 'Radix Sort':
        iterator = 6
    elif val == 'Bucket Sort':
        iterator = 7
    elif val == 'Counting Sort':  
        iterator = 8  
    elif val == 'hybrid_quick_sort_725': 
        iterator = 9   
    elif val == 'Count_Range_Sort_824':
        iterator = 10
            
    Display_Visualization(iterator,Array)

def new_window(Array):
    
    new_window = Tk()
    new_window.title("Sorting Algorithms Visualization")
    new_window.geometry("1000x850")
    new_window.config(bg='maroon')
    algorithm_name = StringVar()
    algo_list = ['Insertion Sort','Bubble Sort', 'Merge Sort','Heap Sort','Quick Sort','Radix Sort','Bucket Sort','Counting Sort', 'hybrid_quick_sort_725','Count_Range_Sort_824']
  
    UI_frame = ttk.Frame(new_window, style="Frame.TFrame", width= 190, height=90)
    UI_frame.grid(row=0, column=0, padx=10, pady=5,sticky=NSEW)
    UI_frame.grid_rowconfigure(0, weight=1)
    UI_frame.grid_columnconfigure(0, weight=0)
    new_window.grid_rowconfigure(0, weight=0)
    new_window.grid_columnconfigure(0, weight=1)
 
    
    l1 = ttk.Label(UI_frame, style="Label.TLabel", text="Algorithm: ")
    
    l1.grid(row=0, column=0, padx=10, pady=10, sticky=W)
    algo_menu = ttk.Combobox(UI_frame,style="Combobox.TCombobox", textvariable=algorithm_name, values=algo_list)
    algo_menu.grid(row=0, column=1, padx=5, pady=5)
    algo_menu.current(0)
    b1 = Button(UI_frame, text="\t\t\t\t Let's Begin\t\t\t\t\t\t ", command= lambda : Sorting_Algorithms(Array,algo_menu.get()), bg='white')
    b1.grid(row=2, column=1, padx=5, pady=5)
    #   sort(Array,val)
        
    # sort button 
 
  
Submitbutton=Button(root,text=" Next ",command=file_reading,bg='White').pack(pady=5)   

mainloop()        